from app.rag import ask

print("\n# 1) Tres sentencias sobre redes sociales")
print(ask("Dime las sentencias (en palabras simples) de 3 demandas relacionadas con redes sociales. Devuelve exactamente 3."))

print("\n# 5) Casos sobre PIAR")
print(ask("¿Existen casos sobre el PIAR? Si los hay, ¿de qué trataron y cuál fue la sentencia?"))

print("\n que PIAR")
print(ask("¿Que es un caso PIAR"))

